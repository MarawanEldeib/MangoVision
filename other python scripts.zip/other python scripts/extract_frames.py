# Filename: extract_frames.py

import cv2
import os

def extract_frames(video_path, output_folder, interval=2):
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    # Open the video file
    video_capture = cv2.VideoCapture(video_path)
    fps = video_capture.get(cv2.CAP_PROP_FPS)  # Frames per second
    frame_interval = int(fps * interval)  # Interval in frames

    success, frame = video_capture.read()
    count = 0
    saved_frame_count = 0

    while success:
        if count % frame_interval == 0:
            frame_filename = os.path.join(output_folder, f"frame_{saved_frame_count:04d}.jpg")
            cv2.imwrite(frame_filename, frame)
            print(f"Saved {frame_filename}")
            saved_frame_count += 1
        success, frame = video_capture.read()
        count += 1

    video_capture.release()
    print(f"Frame extraction completed for {video_path}.")

# Define the list of video paths
video_paths = [
    "D:/2705/SDXC/DCIM/100MEDIA/DJI_0026.MP4",
    "D:/2705/SDXC/DCIM/100MEDIA/DJI_0027.MP4",
    "D:/2705/SDXC/DCIM/100MEDIA/DJI_0028.MP4",
    "D:/2705/SDXC/DCIM/100MEDIA/DJI_0095.MP4",
    "D:/2705/SDXC/DCIM/100MEDIA/DJI_0107.MP4"
]

# Base output folder
base_output_folder = "F:/Final_year_project/yolov8-env/frames"

# Extract frames from each video
for video_path in video_paths:
    video_name = os.path.splitext(os.path.basename(video_path))[0]
    output_folder = os.path.join(base_output_folder, video_name)
    extract_frames(video_path, output_folder, interval=2)
