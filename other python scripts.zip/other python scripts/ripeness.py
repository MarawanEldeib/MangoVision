import cv2
import os
import numpy as np
from sklearn.cluster import KMeans
from sklearn.svm import SVC

# Function to read and convert image to HSV
def read_and_convert_image(file_path):
    if not os.path.exists(file_path):
        print(f"Error: The file at {file_path} does not exist.")
        return None
    image = cv2.imread(file_path)
    if image is None:
        print(f"Error: Unable to read the image at {file_path}. Check the file path and ensure the file exists.")
        return None
    hsv_image = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    return hsv_image

# Path to the image
image_path = r'F:\Final_year_project\mango-segmentation-dataset\mango-segmentation-dataset\tiled-images\test\azure_rgb_5fps_2500expo_001.png'

# Print the directory contents to verify the file
directory_path = os.path.dirname(image_path)
print(f"Contents of directory {directory_path}:")
print(os.listdir(directory_path))

# Read and convert the image
hsv_image = read_and_convert_image(image_path)
if hsv_image is None:
    exit()  # Exit if the image cannot be read

# Extract color histogram as features
hist = cv2.calcHist([hsv_image], [0, 1], None, [180, 256], [0, 180, 0, 256])
hist = cv2.normalize(hist, hist).flatten()

# Clustering with K-means
kmeans = KMeans(n_clusters=3)
kmeans.fit(hist.reshape(-1, 1))
labels = kmeans.labels_

# Manually label clusters for ripeness stages
ripeness_labels = {0: 'unripe', 1: 'ripe', 2: 'overripe'}

# Example: Train a classifier with labeled clusters
X = hist.reshape(-1, 1)
y = np.array([ripeness_labels[label] for label in labels])

classifier = SVC()
classifier.fit(X, y)

# Predict ripeness for another existing image
new_image_path = r'F:\Final_year_project\mango-segmentation-dataset\mango-segmentation-dataset\tiled-images\test\azure_rgb_5fps_2500expo_002.png'
new_hsv_image = read_and_convert_image(new_image_path)
if new_hsv_image is None:
    exit()  # Exit if the image cannot be read

new_hist = cv2.calcHist([new_hsv_image], [0, 1], None, [180, 256], [0, 180, 0, 256])
new_hist = cv2.normalize(new_hist, new_hist).flatten()

ripeness_prediction = classifier.predict(new_hist.reshape(-1, 1))
print(f'Predicted Ripeness: {ripeness_prediction[0]}')
