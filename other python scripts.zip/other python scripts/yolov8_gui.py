import tkinter as tk
from tkinter import filedialog, ttk, messagebox
from PIL import Image, ImageTk, ImageDraw, ImageFont
import cv2
import os
from ultralytics import YOLO
import threading

class YOLOv8GUI:
    def __init__(self, root):
        self.root = root
        self.root.title("YOLOv8 Mango Detection")
        self.root.geometry("1200x800")
        self.conf_threshold = 0.5
        self.theme = "Light"
        self.model_path = 'runs/detect/yolov8_mango_model22/weights/best.pt'
        self.setup_gui()

    def setup_gui(self):
        # Toolbar for settings
        menu = tk.Menu(self.root)
        self.root.config(menu=menu)
        settings_menu = tk.Menu(menu)
        menu.add_cascade(label="Settings", menu=settings_menu)
        settings_menu.add_command(label="Configure", command=self.open_settings)
        settings_menu.add_command(label="Switch Theme", command=self.change_theme)

        self.frame = tk.Frame(self.root, bg='gray90')
        self.frame.pack(fill=tk.BOTH, expand=True)

        # Title
        self.title = tk.Label(self.frame, text="YOLOv8 Mango Detection", font=("Helvetica", 24), bg='gray90')
        self.title.pack(pady=10)

        # Subtitle
        self.subtitle = tk.Label(self.frame, text="Select an image to detect mangoes using YOLOv8.", font=("Helvetica", 14), bg='gray90')
        self.subtitle.pack(pady=5)

        # Model selection dropdown
        self.model_label = tk.Label(self.frame, text="Select Model:", font=("Helvetica", 12), bg='gray90')
        self.model_label.pack(pady=5)
        
        self.model_var = tk.StringVar()
        self.model_dropdown = ttk.Combobox(self.frame, textvariable=self.model_var, state="readonly")
        self.model_dropdown['values'] = (
            'runs/detect/yolov8_mango_model22/weights/best.pt',
            'runs/detect/yolov8_mango_model/weights/best.pt',
            # Add paths to other models here
        )
        self.model_dropdown.current(0)
        self.model_dropdown.pack(pady=5)
        self.model_dropdown.bind("<<ComboboxSelected>>", self.model_selected)

        # Image and Summary Frame
        self.image_summary_frame = tk.Frame(self.frame, bg='gray90')
        self.image_summary_frame.pack(pady=10, expand=True)

        # Image display
        self.image_frame = tk.Frame(self.image_summary_frame, bg='gray90')
        self.image_frame.pack(side=tk.LEFT, padx=10)

        self.image_label = tk.Label(self.image_frame, bg='gray90')
        self.image_label.pack()

        # Summary frame
        self.summary_frame = tk.Frame(self.image_summary_frame, bg='gray90')
        self.summary_frame.pack(side=tk.RIGHT, padx=10, anchor='n')

        # Detection summary
        self.summary_label = tk.Label(self.summary_frame, text="Detection Summary:", font=("Helvetica", 14), bg='gray90')
        self.summary_label.pack(anchor='nw')

        self.summary_text = tk.Text(self.summary_frame, height=20, width=40, bg='gray95', fg='black')
        self.summary_text.pack(anchor='nw', pady=10)

        # Progress bar
        self.progress = tk.DoubleVar()
        self.progress_bar = ttk.Progressbar(self.frame, variable=self.progress, maximum=100, length=200)
        self.progress_bar.pack(pady=10)

        # Button frame
        self.button_frame = tk.Frame(self.frame, bg='gray90')
        self.button_frame.pack(pady=10)

        # Buttons
        self.load_icon = Image.open('cloud-upload.png').resize((50, 50), Image.LANCZOS)
        self.load_icon = ImageTk.PhotoImage(self.load_icon)
        self.load_button = tk.Button(self.button_frame, image=self.load_icon, text="Select Image", compound=tk.TOP, command=self.load_image)
        self.load_button.pack(side=tk.LEFT, padx=10)

        self.detect_icon = Image.open('object.png').resize((50, 50), Image.LANCZOS)
        self.detect_icon = ImageTk.PhotoImage(self.detect_icon)
        self.infer_button = tk.Button(self.button_frame, image=self.detect_icon, text="Detect Mangoes", compound=tk.TOP, state=tk.DISABLED, command=self.run_inference)
        self.infer_button.pack(side=tk.LEFT, padx=10)

        self.save_icon = Image.open('folder-download.png').resize((50, 50), Image.LANCZOS)
        self.save_icon = ImageTk.PhotoImage(self.save_icon)
        self.save_button = tk.Button(self.button_frame, image=self.save_icon, text="Save Results", compound=tk.TOP, state=tk.DISABLED, command=self.save_results)
        self.save_button.pack(side=tk.LEFT, padx=10)

        self.realtime_icon = Image.open('realtime.png').resize((50, 50), Image.LANCZOS)
        self.realtime_icon = ImageTk.PhotoImage(self.realtime_icon)
        self.realtime_button = tk.Button(self.button_frame, image=self.realtime_icon, text="Start Realtime", compound=tk.TOP, command=self.toggle_realtime)
        self.realtime_button.pack(side=tk.LEFT, padx=10)

        self.capture_icon = Image.open('capture.png').resize((50, 50), Image.LANCZOS)
        self.capture_icon = ImageTk.PhotoImage(self.capture_icon)
        self.capture_button = tk.Button(self.button_frame, image=self.capture_icon, text="Capture Image", compound=tk.TOP, command=self.capture_frame)
        self.capture_button.pack(side=tk.LEFT, padx=10)

        # Status bar
        self.status_bar = tk.Label(self.frame, text="Welcome to YOLOv8 Mango Detection", bd=1, relief=tk.SUNKEN, anchor=tk.W, bg='gray90')
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)

        self.load_model()

    def model_selected(self, event):
        self.model_path = self.model_var.get()
        self.load_model()
        self.status_bar.config(text=f"Model {os.path.basename(self.model_path)} loaded successfully.")

    def load_model(self):
        self.model = YOLO(self.model_path)

    def load_image(self):
        file_path = filedialog.askopenfilename()
        if file_path:
            self.image_path = file_path
            image = Image.open(file_path)
            image.thumbnail((400, 450), Image.LANCZOS)
            self.tk_image = ImageTk.PhotoImage(image)
            self.image_label.config(image=self.tk_image)
            self.infer_button.config(state=tk.NORMAL)
            self.save_button.config(state=tk.DISABLED)
            self.status_bar.config(text="Image loaded successfully.")

    def run_inference(self):
        if not hasattr(self, 'image_path'):
            return

        self.progress.set(0)
        self.root.update_idletasks()

        try:
            self.progress.set(50)
            self.root.update_idletasks()

            results = self.model.predict(source=self.image_path, conf=self.conf_threshold, save=False)
            self.progress.set(100)
            self.root.update_idletasks()

            self.display_results(results)
            self.save_button.config(state=tk.NORMAL)
            self.status_bar.config(text="Detection completed successfully.")
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")
            self.status_bar.config(text="Detection failed.")

    def display_results(self, results):
        image = Image.open(self.image_path)
        draw = ImageDraw.Draw(image)
        font = ImageFont.load_default()

        detections = results[0].boxes.xyxy.cpu().numpy()
        confidences = results[0].boxes.conf.cpu().numpy()

        summary = ""
        for i, (box, score) in enumerate(zip(detections, confidences)):
            draw.rectangle([(box[0], box[1]), (box[2], box[3])], outline="green", width=3)
            draw.text((box[0], box[1]), f"Mango {score:.2f}", fill="green", font=font)
            summary += f"Box {i + 1}: Confidence = {score:.2f}\n"

        summary += f"\nTotal Mangoes Detected: {len(detections)}"
        self.summary_text.delete(1.0, tk.END)
        self.summary_text.insert(tk.END, summary)

        image.thumbnail((400, 450), Image.LANCZOS)
        self.tk_result_image = ImageTk.PhotoImage(image)
        self.image_label.config(image=self.tk_result_image)
        self.result_image = image

    def save_results(self):
        if hasattr(self, 'result_image'):
            save_path = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG files", "*.png"), ("All files", "*.*")])
            if save_path:
                self.result_image.save(save_path)
                self.status_bar.config(text=f"Results saved as {save_path}")

    def open_settings(self):
        settings_window = tk.Toplevel(self.root)
        settings_window.title("Settings")
        settings_window.geometry("400x300")

        tk.Label(settings_window, text="Confidence Threshold").pack(pady=10)
        self.conf_slider = tk.Scale(settings_window, from_=0.1, to=1.0, resolution=0.01, orient=tk.HORIZONTAL)
        self.conf_slider.set(self.conf_threshold)
        self.conf_slider.pack(pady=10)
        self.conf_slider.bind("<Motion>", self.update_confidence)

        theme_label = tk.Label(settings_window, text="Select Theme:")
        theme_label.pack(pady=10)
        self.theme_var = tk.StringVar(value="Light")

        light_theme_radio = tk.Radiobutton(settings_window, text="Light", variable=self.theme_var, value="Light", command=self.change_theme)
        dark_theme_radio = tk.Radiobutton(settings_window, text="Dark", variable=self.theme_var, value="Dark", command=self.change_theme)
        light_theme_radio.pack(pady=5)
        dark_theme_radio.pack(pady=5)

    def change_theme(self):
        theme = self.theme_var.get()
        if theme == "Light":
            self.frame.configure(bg='gray90')
            self.title.configure(bg='gray90', fg='black')
            self.subtitle.configure(bg='gray90', fg='black')
            self.progress_bar.configure(style="Light.TProgressbar")
            self.summary_text.configure(bg='gray95', fg='black')
            self.status_bar.configure(bg='gray90', fg='black')
        elif theme == "Dark":
            self.frame.configure(bg='gray20')
            self.title.configure(bg='gray20', fg='white')
            self.subtitle.configure(bg='gray20', fg='white')
            self.progress_bar.configure(style="Dark.TProgressbar")
            self.summary_text.configure(bg='gray20', fg='white')
            self.status_bar.configure(bg='gray20', fg='white')

    def update_confidence(self, event):
        self.conf_threshold = self.conf_slider.get()

    def toggle_realtime(self):
        if hasattr(self, 'cap') and self.cap.isOpened():
            self.stop_camera()
        else:
            self.start_camera()

    def start_camera(self):
        self.cap = cv2.VideoCapture(0)
        self.realtime_button.config(text="Stop Realtime")
        self.load_button.config(state=tk.DISABLED)
        self.summary_frame.pack_forget()
        self.update_frame()

    def stop_camera(self):
        if hasattr(self, 'cap') and self.cap.isOpened():
            self.cap.release()
            self.realtime_button.config(text="Start Realtime")
            self.load_button.config(state=tk.NORMAL)
            self.summary_frame.pack(side=tk.RIGHT, padx=10, anchor='n')

    def update_frame(self):
        ret, frame = self.cap.read()
        if ret:
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = self.model(frame_rgb, conf=self.conf_threshold)
            frame_with_detections = self.draw_detections(frame_rgb, results)

            self.tk_frame_image = ImageTk.PhotoImage(Image.fromarray(frame_with_detections))
            self.image_label.config(image=self.tk_frame_image)
            self.image_label.image = self.tk_frame_image

            self.root.after(10, self.update_frame)

    def draw_detections(self, frame, results):
        detections = results[0].boxes.xyxy.cpu().numpy()
        confidences = results[0].boxes.conf.cpu().numpy()
        for (box, score) in zip(detections, confidences):
            x1, y1, x2, y2 = map(int, box)
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
            cv2.putText(frame, f"Mango {score:.2f}", (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)
        return frame

    def capture_frame(self):
        if hasattr(self, 'cap') and self.cap.isOpened():
            ret, frame = self.cap.read()
            if ret:
                frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                results = self.model(frame_rgb, conf=self.conf_threshold)
                frame_with_detections = self.draw_detections(frame_rgb, results)
                capture_image = Image.fromarray(frame_with_detections)
                save_path = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG files", "*.png"), ("All files", "*.*")])
                if save_path:
                    capture_image.save(save_path)
                    self.status_bar.config(text=f"Captured image saved as {save_path}")

if __name__ == "__main__":
    root = tk.Tk()
    app = YOLOv8GUI(root)
    root.mainloop()
