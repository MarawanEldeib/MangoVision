import detectron2
from detectron2.engine import DefaultPredictor
from detectron2.config import get_cfg
from detectron2 import model_zoo
from detectron2.utils.visualizer import Visualizer, ColorMode
from detectron2.data import MetadataCatalog
import cv2
import os

def setup_cfg():
    # Create a config object
    cfg = get_cfg()
    cfg.merge_from_file(model_zoo.get_config_file("COCO-Detection/faster_rcnn_R_50_FPN_3x.yaml"))

    # Absolute path to your trained model weights (fix the filename if needed)
    cfg.MODEL.WEIGHTS = os.path.abspath(r"F:\Mango Fruit Detection project\Detectron2\Local_dataset_code\Local Dataset DETECTRON2 Results\resnet50_adamw\model_final.pth")

    # Set confidence threshold (adjust as needed)
    cfg.MODEL.ROI_HEADS.SCORE_THRESH_TEST = 0.5
    cfg.MODEL.ROI_HEADS.NUM_CLASSES = 1

    # Get metadata (class names) from your training data
    mango_metadata = MetadataCatalog.get("mango_train")
    cfg.DATASETS.TEST = ("mango_test",)

    return cfg, mango_metadata

def detect_mangoes(predictor, image_path, metadata):
    print(f"Trying to load image from: {image_path}")
    # Load the image with error handling
    im = cv2.imread(image_path)

    if im is None:
        print(f"Error: Could not read image '{image_path}'.")
        print("Please check if the file exists and is in a supported format (JPG, PNG, etc.).")
        return  # Exit the function if image couldn't be loaded

    # Run inference/prediction
    outputs = predictor(im)

    # Visualization
    v = Visualizer(im[:, :, ::-1], metadata=metadata, scale=1.0, instance_mode=ColorMode.SEGMENTATION)
    instances = outputs["instances"].to("cpu")
    boxes = instances.pred_boxes if instances.has("pred_boxes") else None
    scores = instances.scores if instances.has("scores") else None

    if boxes is not None and scores is not None:
        for box, score in zip(boxes, scores):
            box = box.numpy().tolist()
            score = float(score)
            label = f"mango: {score:.2f}"
            v.draw_box(box, edge_color="red", line_style="-")
            v.draw_text(label, (box[0], box[1]), color="red", font_size=15)

    result_image = v.output.get_image()[:, :, ::-1]

    # Save the image instead of displaying
    output_file = "output_image2.jpg"
    cv2.imwrite(output_file, result_image)
    print(f"Detection results saved to: {output_file}")

    # Uncomment the following lines if you want to display the image
    # cv2.imshow("Detection Results", result_image)
    # cv2.waitKey(0)  # Wait for key press before closing
    # cv2.destroyAllWindows()  # Close all OpenCV windows

if __name__ == "__main__":
    cfg, mango_metadata = setup_cfg()
    predictor = DefaultPredictor(cfg)

    # Update the image path
    image_path = r"F:\Mango Fruit Detection project\Detectron2\CQUniversity_dataset (need_to be_fixed)\Mango Fruit Detection.v3i.coco\train\azure_rgb_5fps_2500expo_182_png.rf.c0724bc74fc3c28eeaa9f73d0fa0d0f2.jpg"  # Absolute path to your test image

    detect_mangoes(predictor, image_path, mango_metadata)
