import os
import shutil
from ultralytics import YOLO

# Paths to dataset
train_images_dir = "F:/Final_year_project/yolov8-env/Mango Fruit Detection.v2i.yolov8/train/images"
val_images_dir = "F:/Final_year_project/yolov8-env/Mango Fruit Detection.v2i.yolov8/valid/images"
test_images_dir = "F:/Final_year_project/yolov8-env/Mango Fruit Detection.v2i.yolov8/test/images"
train_labels_dir = "F:/Final_year_project/yolov8-env/Mango Fruit Detection.v2i.yolov8/train/labels"
val_labels_dir = "F:/Final_year_project/yolov8-env/Mango Fruit Detection.v2i.yolov8/valid/labels"
test_labels_dir = "F:/Final_year_project/yolov8-env/Mango Fruit Detection.v2i.yolov8/test/labels"

# Ensure directories exist
for directory in [train_images_dir, val_images_dir, test_images_dir, train_labels_dir, val_labels_dir, test_labels_dir]:
    if not os.path.exists(directory):
        print(f"Error: {directory} does not exist.")
        exit(1)

# Define the data.yaml configuration for YOLOv8
data_yaml_content = f"""
train: {train_images_dir}
val: {val_images_dir}
test: {test_images_dir}
nc: 1
names: ['mango']
"""

# Write data.yaml file
data_yaml_path = "F:/Final_year_project/yolov8-env/data.yaml"
with open(data_yaml_path, 'w') as f:
    f.write(data_yaml_content)

# Initialize the YOLOv8 model with the existing weights
model = YOLO('runs/detect/yolov8_mango_model/weights/best.pt')  # Load the existing model weights

# Train the model for an additional 20 epochs
model.train(data=data_yaml_path, epochs=20, imgsz=640, batch=16, name='yolov8_mango_model2')  # Change the name to start a new training

print("Training completed!")
