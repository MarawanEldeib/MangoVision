import detectron2
from detectron2.engine import DefaultPredictor
from detectron2.config import get_cfg
from detectron2 import model_zoo
from detectron2.utils.visualizer import Visualizer,ColorMode
from detectron2.data import MetadataCatalog
import cv2
import os

def setup_cfg():
    # Create a config object
    cfg = get_cfg()
    cfg.merge_from_file(model_zoo.get_config_file("COCO-Detection/faster_rcnn_R_50_FPN_3x.yaml")) 

    # Absolute path to your trained model weights (fix the filename if needed)
    cfg.MODEL.WEIGHTS = os.path.abspath(r"F:\Mango Fruit Detection project\Detectron2\SydneyUniversity_dataset_code\Sydney Dataset DETECTRON2 Results\resnet50_adamw\model_final.pth")

    # Set confidence threshold (adjust as needed)
    cfg.MODEL.ROI_HEADS.SCORE_THRESH_TEST = 0.5 
    cfg.MODEL.ROI_HEADS.NUM_CLASSES = 1

    # Get metadata (class names) from your training data
    mango_metadata = MetadataCatalog.get("mango_train") 
    cfg.DATASETS.TEST = ("mango_test",)

    return cfg, mango_metadata

def detect_mangoes(predictor, image_path, metadata):
    print(f"Trying to load image from: {image_path}") 
    # Load the image with error handling
    im = cv2.imread(image_path)

    if im is None:
        print(f"Error: Could not read image '{image_path}'.")
        print("Please check if the file exists and is in a supported format (JPG, PNG, etc.).")
        return  # Exit the function if image couldn't be loaded


    # Run inference/prediction
    outputs = predictor(im)  

    # Visualization (choose ONE method)

    # 1. Simple Bounding Boxes:
 # Visualize results (without cv2.imshow)
    v = Visualizer(im[:, :, ::-1], metadata=metadata, scale=1.0)
    v = v.draw_instance_predictions(outputs["instances"].to("cpu"))
    result_image = v.get_image()[:, :, ::-1]
    
    # Save the image instead of displaying
    output_file = "output_image.jpg"  
    cv2.imwrite(output_file, result_image)
    print(f"Detection results saved to: {output_file}")  

    # 2. Fancy Visualization with Detectron2's draw_instances():
    # (This requires installing the 'Pillow' library: pip install Pillow)
    # v = Visualizer(im[:, :, ::-1], metadata=metadata, scale=1.2)
    # v.draw_instance_predictions(outputs["instances"].to("cpu"))
    # v.save("output_image.jpg")  # Save instead of showing

    cv2.waitKey(0)  # Wait for key press before closing


if __name__ == "__main__":
    cfg, mango_metadata = setup_cfg()
    predictor = DefaultPredictor(cfg)

    # Update the image path 
    image_path = r"f:\Mango Fruit Detection project\Detectron2\SydneyUniversity_dataset_code\detectron2_split_dataset-20240706T042233Z-001\detectron2_split_dataset\val\images\20151124T042351.077709_i2060j1012.png"  # Absolute path to your test image

    detect_mangoes(predictor, image_path, mango_metadata)